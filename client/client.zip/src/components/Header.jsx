import { Link, NavLink, useNavigate } from "react-router-dom";
import { useEffect, useState } from "react";
import { cartCount } from "../cart.js";

function parseUser() {
  try {
    return JSON.parse(localStorage.getItem("adeline_user") || "null");
  } catch {
    return null;
  }
}

export default function Header() {
  const [count, setCount] = useState(cartCount());
  const [user, setUser] = useState(parseUser());
  const navigate = useNavigate();
  const isAdmin = user?.role === "admin";

  useEffect(() => {
    const refresh = () => {
      setCount(cartCount());
      setUser(parseUser());
    };

    window.addEventListener("adeline-cart", refresh);
    window.addEventListener("adeline-cart-updated", refresh);
    window.addEventListener("storage", refresh);

    return () => {
      window.removeEventListener("adeline-cart", refresh);
      window.removeEventListener("adeline-cart-updated", refresh);
      window.removeEventListener("storage", refresh);
    };
  }, []);

  const logout = () => {
    localStorage.removeItem("adeline_token");
    localStorage.removeItem("adeline_user");
    setUser(null);
    navigate("/");
  };

  return (
    <header className="adeline-shell-header">
      <div className="adeline-benefits-topbar">
        <div>
          <span>▱</span>
          <b>ENVÍOS A TODO EL PAÍS</b>
          <small>Rápidos y seguros</small>
        </div>
        <div>
          <span>▭</span>
          <b>3 CUOTAS SIN INTERÉS</b>
          <small>En toda la tienda</small>
        </div>
        <div>
          <span>%</span>
          <b>10% OFF TRANSFERENCIA</b>
          <small>Pagando por transferencia</small>
        </div>
        <div>
          <span>↺</span>
          <b>CAMBIOS Y DEVOLUCIONES</b>
          <small>Fáciles y sin costo</small>
        </div>
      </div>

      <div className="adeline-main-header">
        <div className="adeline-header-left">
          <button className="adeline-menu-btn" type="button" aria-label="Abrir menú">
            ☰
          </button>
          <label className="adeline-search-box">
            <input type="search" placeholder="Buscar productos..." />
            <span>⌕</span>
          </label>
        </div>

        <Link to="/" className="adeline-header-logo" aria-label="Adeline inicio">
          <img src="/brand/adeline-logo-transparent.png" alt="Adeline" />
        </Link>

        <div className="adeline-header-actions">
          {user ? (
            <Link className="adeline-account-link" to="/admin/productos">
              {isAdmin ? "Admin" : user.nombre || "Cuenta"}
            </Link>
          ) : (
            <Link className="adeline-account-link" to="/login">
              ♙
            </Link>
          )}

          <Link className="adeline-cart-link" to="/carrito" aria-label="Carrito">
            ♡
            <span>{count}</span>
          </Link>

          {user && (
            <button className="adeline-logout-btn" type="button" onClick={logout}>
              Salir
            </button>
          )}
        </div>
      </div>

      <nav className="adeline-nav-modern">
        <NavLink to="/">NEW IN</NavLink>
        <a href="/#tienda">TOPS</a>
        <a href="/#coleccion">DENIM</a>
        <a href="/#coleccion">VESTIDOS</a>
        <a href="/#coleccion">ACCESORIOS</a>
        <a href="/#tienda" className="sale-link">SALE</a>
        {isAdmin && (
          <>
            <NavLink to="/admin/productos" className="admin-header-link">
              PRODUCTOS
            </NavLink>
            <NavLink to="/admin/pedidos" className="admin-header-link">
              PEDIDOS
            </NavLink>
          </>
        )}
      </nav>
    </header>
  );
}
