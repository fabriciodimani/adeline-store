import { useEffect, useMemo, useState } from "react";
import { apiGet } from "../api.js";
import { mockProducts } from "../mockProducts.js";
import ProductCard from "../components/ProductCard.jsx";

const editorialImages = {
  hero:
    "https://images.unsplash.com/photo-1496747611176-843222e1e57c?auto=format&fit=crop&w=1800&q=88",
  best:
    "https://images.unsplash.com/photo-1529139574466-a303027c1d8b?auto=format&fit=crop&w=1100&q=86",
  denim:
    "https://images.unsplash.com/photo-1541099649105-f69ad21f3246?auto=format&fit=crop&w=1100&q=86",
  street:
    "https://images.unsplash.com/photo-1483985988355-763728e1935b?auto=format&fit=crop&w=1100&q=86",
  winter:
    "https://images.unsplash.com/photo-1503342217505-b0a15ec3261c?auto=format&fit=crop&w=1100&q=86",
  accessories:
    "https://images.unsplash.com/photo-1548036328-c9fa89d128fa?auto=format&fit=crop&w=1100&q=86",
  club:
    "https://images.unsplash.com/photo-1520975682031-a4b3f41e927f?auto=format&fit=crop&w=1300&q=86",
};

const collectionTiles = [
  { title: "BEST SELLERS", image: editorialImages.best },
  { title: "DENIM EDIT", image: editorialImages.denim },
  { title: "STREET LOOKS", image: editorialImages.street },
  { title: "WINTER ESSENTIALS", image: editorialImages.winter },
  { title: "ACCESORIOS", image: editorialImages.accessories },
];

function pickProducts(products, count = 6) {
  const real = Array.isArray(products) && products.length ? products : mockProducts;
  return real.slice(0, count);
}

export default function Home() {
  const [products, setProducts] = useState(mockProducts);

  useEffect(() => {
    apiGet("/api/products")
      .then((data) => {
        const list = Array.isArray(data?.items) ? data.items : data;
        if (Array.isArray(list) && list.length) setProducts(list);
      })
      .catch(() => setProducts(mockProducts));
  }, []);

  const newIn = useMemo(() => pickProducts(products, 6), [products]);
  const instagram = useMemo(() => pickProducts(products, 5), [products]);

  return (
    <main className="adeline-home-modern">
      <section className="adeline-hero-editorial" id="inicio">
        <div className="adeline-hero-image" style={{ backgroundImage: `url(${editorialImages.hero})` }} />

        <div className="adeline-hero-panel">
          <p>NUEVA COLECCIÓN</p>
          <h1>Street Style</h1>
          <span>Looks que te acompañan de día y de noche.</span>

          <div className="adeline-hero-actions">
            <a href="#tienda" className="adeline-btn-light">
              COMPRAR AHORA
            </a>
            <a href="#coleccion" className="adeline-btn-outline">
              VER LOOKS
            </a>
          </div>
        </div>
      </section>

      <section className="adeline-collection-grid" id="coleccion">
        {collectionTiles.map((item) => (
          <a href="#tienda" className="adeline-collection-tile" key={item.title}>
            <img src={item.image} alt={item.title} loading="lazy" />
            <div>
              <h2>{item.title}</h2>
              <span>Ver más →</span>
            </div>
          </a>
        ))}
      </section>

      <section className="adeline-new-in" id="tienda">
        <div className="adeline-section-title">
          <span />
          <h2>New In</h2>
          <a href="#tienda">VER TODO</a>
        </div>

        <div className="adeline-products-row">
          {newIn.map((product) => (
            <ProductCard key={product._id} product={product} compact />
          ))}
        </div>

        <div className="adeline-center-action">
          <a href="#tienda">VER TODOS LOS PRODUCTOS</a>
        </div>
      </section>

      <section className="adeline-benefits-modern">
        <article>
          <div>▱</div>
          <b>ENVÍOS A TODO EL PAÍS</b>
          <p>Envíos rápidos y seguros a donde estés.</p>
        </article>
        <article>
          <div>▭</div>
          <b>3 CUOTAS SIN INTERÉS</b>
          <p>En todas las compras con tarjetas seleccionadas.</p>
        </article>
        <article>
          <div>%</div>
          <b>10% OFF TRANSFERENCIA</b>
          <p>Aprovechá el descuento en tu compra.</p>
        </article>
        <article>
          <div>☏</div>
          <b>ATENCIÓN PERSONALIZADA</b>
          <p>Estamos para ayudarte por WhatsApp y email.</p>
        </article>
      </section>

      <section className="adeline-instagram-section">
        <h2>@ADELINE.OFICIAL</h2>
        <div className="adeline-instagram-grid">
          {instagram.map((product) => (
            <a key={product._id} href={`/producto/${product._id}`}>
              <ProductCard product={product} imageOnly />
            </a>
          ))}
        </div>
        <a className="adeline-instagram-btn" href="#inicio">
          VER MÁS EN INSTAGRAM
        </a>
      </section>

      <section className="adeline-club-section">
        <div className="adeline-club-photo" style={{ backgroundImage: `url(${editorialImages.club})` }} />
        <div className="adeline-club-copy">
          <span>SUSCRIBITE A</span>
          <h2>Adeline Club</h2>
          <p>Recibí antes que nadie novedades, lanzamientos y beneficios exclusivos.</p>
          <form onSubmit={(e) => e.preventDefault()}>
            <input type="email" placeholder="Tu correo electrónico" />
            <button type="submit">SUSCRIBIRME</button>
          </form>
        </div>
      </section>

      <footer className="adeline-footer-modern" id="contacto">
        <div>
          <h3>NAVEGACIÓN</h3>
          <a href="#inicio">Nuevo</a>
          <a href="#tienda">Ropa</a>
          <a href="#coleccion">Denim</a>
          <a href="#coleccion">Vestidos</a>
          <a href="#tienda">Sale</a>
        </div>
        <div>
          <h3>AYUDA</h3>
          <a href="#inicio">Preguntas frecuentes</a>
          <a href="#inicio">Guía de talles</a>
          <a href="#inicio">Envíos</a>
          <a href="#inicio">Cambios y devoluciones</a>
        </div>
        <div>
          <h3>CONTACTO</h3>
          <p>WhatsApp: 11 1234 5678</p>
          <p>hola@adeline.com.ar</p>
          <p>Lunes a Viernes de 9 a 18 hs.</p>
        </div>
        <div>
          <h3>SEGUINOS</h3>
          <p>Instagram · Facebook</p>
        </div>
        <div className="adeline-footer-brand">
          <img src="/brand/adeline-logo-transparent.png" alt="Adeline" />
          <p>Diseñado para mujeres reales. Hecho para todos los días.</p>
        </div>
        <div className="adeline-payment-row">
          <span>Medios de pago</span>
          <b>VISA</b>
          <b>Mastercard</b>
          <b>Amex</b>
          <b>Naranja X</b>
          <b>Mercado Pago</b>
        </div>
      </footer>
    </main>
  );
}
